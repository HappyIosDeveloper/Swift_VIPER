//
//  HomeViewBuilder.swift
//  Viper
//
//  Created by Ahmadreza on 3/23/23.
//

import UIKit

class UsersViewBuilder {
    
    static func build(users: [User])-> UsersViewController {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "UsersViewController") as! UsersViewController
        let router = UsersRouter()
        let interactor = UsersInteractor(users: users)
        let presenter = UsersPresenter(view: vc, router: router, interactor: interactor)
        vc.presenter = presenter
        return vc
    }
}
