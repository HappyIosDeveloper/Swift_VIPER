//
//  ViewController.swift
//  Viper
//
//  Created by Ahmadreza on 3/15/23.
//

import UIKit

protocol UsersView: AnyObject {
    func setupViews()
    func loadTableView()
}

class UsersViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var presenter: UsersPresenter!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("init UsersViewController")
        presenter.didLoad()
    }
    
    deinit {
        print("deinit - UsersViewController")
    }
}

// MARK: - Custom Functions
extension UsersViewController: UsersView {
    
    func setupViews() {
        setupTitle()
        setupTableView()
    }
    
    func loadTableView() {
        tableView.reloadData()
    }
    
    private func setupTitle() {
        navigationItem.title = "Users"
    }
    
    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
    }
}

// MARK: - TableView Functions
extension UsersViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return presenter.interactor.users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = presenter.interactor.users[indexPath.row].title
        return cell
    }
}
