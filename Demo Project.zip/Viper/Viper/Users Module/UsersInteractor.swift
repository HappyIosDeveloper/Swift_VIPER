//
//  UsersInteractor.swift
//  Viper
//
//  Created by Ahmadreza on 3/23/23.
//

import Foundation

protocol UsersInteracting {
    
}

class UsersInteractor: UsersInteracting {
    
    var users: [User]
    
    init(users: [User]) {
        print("init - UsersInteractor")
        self.users = users
    }
}
