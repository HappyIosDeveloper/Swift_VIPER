//
//  UsersPresenter.swift
//  Viper
//
//  Created by Ahmadreza on 3/23/23.
//

import Foundation

protocol UsersPresenting {
    func didLoad()
}

class UsersPresenter: UsersPresenting {
    
    weak var view: UsersView? // view must be weak to avoid retain cycle
    var router: UsersRouter
    var interactor: UsersInteractor
    
    init(view: UsersView, router: UsersRouter, interactor: UsersInteractor) {
        self.view = view
        self.router = router
        self.interactor = interactor
        print("init - UsersPresenter")
    }
}

// MARK: - Custom Functions
extension UsersPresenter {
    
    func didLoad() {
        view?.setupViews()
    }
}
