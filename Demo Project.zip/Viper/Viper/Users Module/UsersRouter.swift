//
//  UsersRouter.swift
//  Viper
//
//  Created by Ahmadreza on 3/23/23.
//

import Foundation

protocol UsersRouting {
    
}

class UsersRouter: UsersRouting {
    
    init() {
        print("init - UsersRouter")
    }
}
