//
//  HomeInteractor.swift
//  Viper
//
//  Created by Ahmadreza on 3/15/23.
//

import Foundation

enum MyError: Error { case serverError, parseIssue, wrongURL}
protocol HomeInteracting {
    var users: [User] { get }
    func getUsers(users: @escaping (Result<[User], MyError>) -> ())
}

class HomeInteractor: HomeInteracting {
        
    var users: [User] = []
    
    init() {
        print("init - HomeInteractor")
    }
}

// MARK: - Custom Functions
extension HomeInteractor {
    
    func getUsers(users completion: @escaping (Result<[User], MyError>) -> ()) {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else { return completion(.failure(.wrongURL)) }
        URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, error in
            if let data = data {
                if let users = try? JSONDecoder().decode([User].self, from: data) {
                    self.users = users
                    completion(.success(users))
                    return
                } else {
                    completion(.failure(.parseIssue))
                }
            } else {
                completion(.failure(.serverError))
            }
        }.resume()
    }
}
