//
//  HomeViewBuilder.swift
//  Viper
//
//  Created by Ahmadreza on 3/15/23.
//

import UIKit

class HomeViewBuilder {
    
    static func build()-> HomeViewController {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        let router = HomeRouter()
        let interactor = HomeInteractor()
        let presenter = HomePresenter(view: vc, interactor: interactor, router: router)
        vc.presenter = presenter
        return vc
    }
}
