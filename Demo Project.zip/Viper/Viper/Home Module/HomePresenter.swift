//
//  HomePresenter.swift
//  Viper
//
//  Created by Ahmadreza on 3/15/23.
//

import Foundation

protocol HomePresenting {
    func viewDidLoad()
}

class HomePresenter: HomePresenting {
    
    weak var view: HomeView? // view must be weak to avoid retain cycle
    var router: HomeRouting
    var interactor: HomeInteracting
    
    init(view: HomeView , interactor: HomeInteracting, router: HomeRouting) {
        self.view = view
        self.router = router
        self.interactor = interactor
        print("init - HomePresenter")
    }
}

// MARK: - Custom Functions
extension HomePresenter {
    
    func viewDidLoad() {
        view?.setupViews()
        getUsers()
    }
    
    private func getUsers() {
        setupLoadingMode()
        interactor.getUsers { [self] response in
            DispatchQueue.main.async { [self] in
                switch response {
                case .success(let users):
                    setupLoadedDataMode(users: users)
                case .failure(let error):
                    setupErrorMode()
                    print("Oops! error happened =>", error.localizedDescription)
                }
            }
        }
    }
    
    private func setupLoadingMode() {
        view?.updateUsers(users: [])
        view?.setupLoading(isAnimating: true)
        view?.setupShowUsersButton(isHidden: true)
    }
    
    private func setupLoadedDataMode(users: [User]) {
        view?.updateUsers(users: users)
        view?.setupLoading(isAnimating: false)
        view?.setupShowUsersButton(isHidden: false)
    }
    
    private func setupErrorMode() {
        view?.updateUsers(users: [])
        view?.setupLoading(isAnimating: false)
        view?.setupShowUsersButton(isHidden: false)
    }
}
