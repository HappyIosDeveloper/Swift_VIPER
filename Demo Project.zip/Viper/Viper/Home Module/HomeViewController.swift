//
//  HomeViewController.swift
//  Viper
//
//  Created by Ahmadreza on 3/15/23.
//

import UIKit


protocol HomeView: AnyObject {
    func setupViews()
    func updateUsers(users: [User])
    func setupLoading(isAnimating: Bool)
    func setupShowUsersButton(isHidden: Bool)
}

class HomeViewController: UIViewController {
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    @IBOutlet weak var showUsersButton: UIButton!
    @IBAction func showUsersButtonAction(_ sender: Any) {
        presenter?.router.showUsersController(users: presenter?.interactor.users ?? [])
    }
    
    var presenter: HomePresenter?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        print("viewDidLoad - HomeViewController")
        presenter?.viewDidLoad()
    }
}

// MARK: - Custom Functions
extension HomeViewController: HomeView {
    
    func setupLoading(isAnimating: Bool) {
        isAnimating ? indicator.startAnimating() : indicator.stopAnimating()
    }
    
    func setupShowUsersButton(isHidden: Bool) {
        showUsersButton.isHidden = isHidden
    }
    
    func updateUsers(users: [User]) {
        if users.isEmpty {
            label.text = ""
        } else {
            label.text = users.count.description + " Users"
        }
    }
    
    func setupViews() {
        setupTitle()
        updateUsers(users: [])
        setupLoading(isAnimating: true)
        setupShowUsersButton(isHidden: true)
    }
    
    private func setupTitle() {
        navigationItem.title = " Home"
    }
}
