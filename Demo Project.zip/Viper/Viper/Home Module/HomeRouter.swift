//
//  HomeRouter.swift
//  Viper
//
//  Created by Ahmadreza on 3/15/23.
//

import UIKit

protocol HomeRouting {
    func showUsersController(users: [User])
}

class HomeRouter: HomeRouting {
    
    var nav: UINavigationController? {
        get {
            let allScenes = UIApplication.shared.connectedScenes
            let scene = allScenes.first { $0.activationState == .foregroundActive }
            return (scene as? UIWindowScene)?.keyWindow?.rootViewController as? UINavigationController
        }
    }
    
    init() {
        print("init - HomeRouter")
    }
}

// MARK: - Custom Functions
extension HomeRouter {
    
    func showUsersController(users: [User]) {
        let vc = UsersViewBuilder.build(users: users)
        nav?.pushViewController(vc, animated: true)
    }
}
